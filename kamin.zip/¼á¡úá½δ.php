<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Главная</title>
<meta name="generator" content="WYSIWYG Web Builder 9 - http://www.wysiwygwebbuilder.com">
<style type="text/css">
html, body
{
   height: 100%;
}
div#space
{
   width: 1px;
   height: 50%;
   margin-bottom: -3051px;
   float:left
}
div#container
{
   width: 1002px;
   height: 6103px;
   margin: 0 auto;
   position: relative;
   clear: left;
}
body
{
   background-color: #FFFFFF;
   background-image: url(images/cvetnoy_korichnevyi_kirpich.png);
   color: #000000;
   font-family: Arial;
   font-size: 13px;
   margin: 0;
   padding: 0;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#Image1
{
   border: 0px #000000 solid;
}
#Image2
{
   border: 0px #000000 solid;
}
#Image3
{
   border: 0px #000000 solid;
}
#Marquee1
{
   background-color: transparent;
   background-image: url(images/%3C%30%3D%33%30%3B%4B_Marquee1_bkgrnd.png);
   background-repeat: repeat-x;
   background-position: left top;
   border: 1px #C0C0C0 solid;
   text-align: center;
}
#wb_CssMenu2
{
   border: 0px #C0C0C0 solid;
   background-color: transparent;
}
#wb_CssMenu2 ul
{
   list-style-type: none;
   margin: 0;
   padding: 0;
   position: relative;
   display: inline-block;
}
#wb_CssMenu2 li
{
   float: left;
   margin: 0;
   padding: 0px 21px 0px 0px;
   width: 115px;
}
#wb_CssMenu2 a
{
   display: block;
   float: left;
   color: #2F4F4F;
   border: 1px #C0C0C0 solid;
   background-color: #EEEEEE;
   background-image: none;
   font-family: Arial;
   font-size: 24px;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   width: 103px;
   height: 26px;
   padding: 0px 5px 0px 5px;
   vertical-align: middle;
   line-height: 26px;
   text-align: center;
}
#wb_CssMenu2 li:hover a, #wb_CssMenu2 a:hover
{
   color: #666666;
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
}
#wb_CssMenu2 li.firstmain
{
   padding-left: 0px;
}
#wb_CssMenu2 li.lastmain
{
   padding-right: 0px;
}
#wb_CssMenu2 li:hover, #wb_CssMenu2 li a:hover
{
   position: relative;
}
#wb_CssMenu2 a.withsubmenu
{
   padding: 0 5px 0 5px;
   width: 103px;
   background-image: none;
}
#wb_CssMenu2 li:hover a.withsubmenu, #wb_CssMenu2 a.withsubmenu:hover
{
   background-image: none;
}
#wb_CssMenu2 ul ul
{
   position: absolute;
   left: -9999px;
   top: -9999px;
   width: 100px;
   height: auto;
   border: none;
   background-color: transparent;
}
#wb_CssMenu2 ul :hover ul
{
   left: 0px;
   top: 28px;
   padding-top: 0px;
}
#wb_CssMenu2 .firstmain:hover ul
{
   left: 0px;
}
#wb_CssMenu2 li li
{
   width: 100px;
   padding: 0 0px 0px 0px;
   border: 0px #C0C0C0 solid;
   border-width: 0 0px;
}
#wb_CssMenu2 li li.firstitem
{
   border-top: 0px #C0C0C0 solid;
}
#wb_CssMenu2 li li.lastitem
{
   border-bottom: 0px #C0C0C0 solid;
}
#wb_CssMenu2 ul ul a, #wb_CssMenu2 ul :hover ul a
{
   float: none;
   margin: 0;
   width: 86px;
   height: auto;
   white-space: normal;
   padding: 5px 6px 5px 6px;
   background-color: #EEEEEE;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #696969;
   font-family: Arial;
   font-size: 13px;
   font-weight: normal;
   font-style: normal;
   line-height: 13px;
   text-align: left;
   text-decoration: none;
}
#wb_CssMenu2 ul :hover ul .firstitem a
{
   margin-top: 0px;
}
#wb_CssMenu2 ul ul :hover a, #wb_CssMenu2 ul ul a:hover, #wb_CssMenu2 ul ul :hover ul :hover a, #wb_CssMenu2 ul ul :hover ul a:hover
{
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #666666;
}
#wb_CssMenu2 br
{
   clear: both;
   font-size: 1px;
   height: 0;
   line-height: 0;
}
#PhotoGallery1
{
   border-spacing: 3px;
   width: 100%;
}
#PhotoGallery1 .figure
{
   padding: 0px 0px 0px 0px;
   text-align: center;
   vertical-align: top;
}
#PhotoGallery1 .figure img
{
   border: 0px #000000 solid;
}
</style>
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape3" style="position:absolute;left:158px;top:246px;width:153px;height:50px;z-index:0;">
<img src="images/img0010.png" id="Shape3" alt="" style="border-width:0;width:153px;height:50px;"></div>
<div id="wb_Shape1" style="position:absolute;left:162px;top:217px;width:100px;height:100px;z-index:1;">
<img src="images/img0011.png" id="Shape1" alt="" style="border-width:0;width:100px;height:100px;"></div>
<div id="wb_Shape2" style="position:absolute;left:1px;top:31px;width:1039px;height:292px;z-index:2;">
<img src="images/img0012.png" id="Shape2" alt="" style="border-width:0;width:1039px;height:292px;"></div>
<div id="wb_Image1" style="position:absolute;left:397px;top:85px;width:209px;height:158px;z-index:3;">
<img src="images/ogon10.gif" id="Image1" alt="" style="width:209px;height:158px;"></div>
<div id="wb_Image2" style="position:absolute;left:14px;top:73px;width:153px;height:164px;z-index:4;">
<img src="images/15e7cdaa9fb7d490c175c7dcf436b32f.png" id="Image2" alt="" style="width:153px;height:164px;"></div>
<div id="wb_Image3" style="position:absolute;left:806px;top:66px;width:188px;height:177px;z-index:5;">
<img src="images/barbecue.png" id="Image3" alt="" style="width:188px;height:177px;"></div>
<div id="wb_TextArt1" style="position:absolute;left:256px;top:62px;width:495px;height:49px;z-index:6;">
<img src="images/img0013.png" id="TextArt1" alt="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" title="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" style="border-width:0;width:495px;height:49px;"></div>
<div id="wb_Shape4" style="position:absolute;left:15px;top:422px;width:1039px;height:1873px;z-index:7;">
<a href="./мангалы.php"><img src="images/img0014.png" id="Shape4" alt="" style="border-width:0;width:1039px;height:1873px;"></a></div>
<marquee direction="left" scrolldelay="90" scrollamount="2" behavior="alternate" loop="0" style="position:absolute;left:86px;top:344px;width:851px;height:42px;z-index:8;" id="Marquee1"><span style="color:#000000;font-family:Arial;font-size:32px;"><em>Строительство уличных кухонных комплексов</em></span></marquee>
<div id="wb_CssMenu2" style="position:absolute;left:150px;top:266px;width:680px;height:100px;text-align:center;z-index:9;">
<ul>
<li class="firstmain"><a href="./index.php" target="_self">&#1043;&#1083;&#1072;&#1074;&#1085;&#1072;&#1103;</a>
</li>
<li><a class="withsubmenu" href="./галерея.php" target="_self">&#1043;&#1072;&#1083;&#1077;&#1088;&#1077;&#1103;</a>

<ul>
<li class="firstitem"><a href="./мангалы.php" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;</a>
</li>
<li><a href="./камины.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./кафель.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li class="lastitem"><a href="./сауны.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./о_нас.php" target="_self">&#1054;&nbsp;&#1085;&#1072;&#1089;</a>
</li>
<li><a class="withsubmenu" href="./статьи.php" target="_self">&#1057;&#1090;&#1072;&#1090;&#1100;&#1080;</a>

<ul>
<li class="firstitem"><a href="./камины.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./кафель.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li><a href="./мангалы_печи.php" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;&nbsp;&#1087;&#1077;&#1095;&#1080;</a>
</li>
<li class="lastitem"><a href="./сауны.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./контакты.php" target="_self">&#1050;&#1086;&#1085;&#1090;&#1072;&#1082;&#1090;&#1099;</a>
</li>
</ul>
<br>
</div>
<div id="wb_PhotoGallery1" style="position:absolute;left:29px;top:494px;width:1012px;height:1710px;z-index:10;">
<table id="PhotoGallery1">
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170302_111525.jpg"><img alt="" title="" src="images/20170302_111525.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170302_111610.jpg"><img alt="" title="" src="images/20170302_111610.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170314_123947.jpg"><img alt="" title="" src="images/20170314_123947.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170506_145342.jpg"><img alt="" title="" src="images/20170506_145342.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170518_154329.jpg"><img alt="" title="" src="images/20170518_154329.jpg" style="width:248px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170518_154515.jpg"><img alt="" title="" src="images/20170518_154515.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170906_160639.jpg"><img alt="" title="" src="images/20170906_160639.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/20170906_160736.jpg"><img alt="" title="" src="images/20170906_160736.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/28413372.jpg"><img alt="" title="" src="images/28413372.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/30078594%20%282%29.jpg"><img alt="" title="" src="images/30078594%20%282%29.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/31027930.jpg"><img alt="" title="" src="images/31027930.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMAG0639.jpg"><img alt="" title="" src="images/IMAG0639.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMAG0644.jpg"><img alt="" title="" src="images/IMAG0644.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-01-7ab466ca4eabfcaa2b089aba7c151c1fb4447691860c97d85e874baf7bece955-V.jpg"><img alt="" title="" src="images/image-0-02-01-7ab466ca4eabfcaa2b089aba7c151c1fb4447691860c97d85e874baf7bece955-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-01-f259e268840b738fc9db290b6e66cf28cf0a7c721a73dbdba39ccaa72e19aefe-V.jpg"><img alt="" title="" src="images/image-0-02-01-f259e268840b738fc9db290b6e66cf28cf0a7c721a73dbdba39ccaa72e19aefe-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-04-4cbe99d08ae927164a87a416f22c7781770785b1d133a55201e8034c4605b24b-V-1.jpg"><img alt="" title="" src="images/image-0-02-04-4cbe99d08ae927164a87a416f22c7781770785b1d133a55201e8034c4605b24b-V-1.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-04-5f3df8102e0373e5ec144d16e0a2d4c3cfbb1139b8a06de2eb368bd7e4892260-V.jpg"><img alt="" title="" src="images/image-0-02-04-5f3df8102e0373e5ec144d16e0a2d4c3cfbb1139b8a06de2eb368bd7e4892260-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-1dc2184fa3b1d488ebb1fe764331c7af6f038f42fc8f654899df03b5cf0df225-V.jpg"><img alt="" title="" src="images/image-0-02-05-1dc2184fa3b1d488ebb1fe764331c7af6f038f42fc8f654899df03b5cf0df225-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-5a7fca189b2fd844c5ffdb3bc77a6e3b2fdadcaa44b68efecba94a380e523ee0-V.jpg"><img alt="" title="" src="images/image-0-02-05-5a7fca189b2fd844c5ffdb3bc77a6e3b2fdadcaa44b68efecba94a380e523ee0-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-024a077c0b005255770e0b7ca2d17346e852f8f501924ace124607cc98b7e09b-V-1.jpg"><img alt="" title="" src="images/image-0-02-05-024a077c0b005255770e0b7ca2d17346e852f8f501924ace124607cc98b7e09b-V-1.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-33f5a3ca7d3888251e72a53e6a36822fbc45e4d29794f76a0bae976f061fb483-V.jpg"><img alt="" title="" src="images/image-0-02-05-33f5a3ca7d3888251e72a53e6a36822fbc45e4d29794f76a0bae976f061fb483-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-75c205ff7e1e89a76520350ea039f4714a6b6bd91b96a2cb716f883cba545554-V-1.jpg"><img alt="" title="" src="images/image-0-02-05-75c205ff7e1e89a76520350ea039f4714a6b6bd91b96a2cb716f883cba545554-V-1.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-79b676eefcad0ad65f78f9f7dd4e3747b1f787d821321158fa2a9d0c1ebcdfb3-V.jpg"><img alt="" title="" src="images/image-0-02-05-79b676eefcad0ad65f78f9f7dd4e3747b1f787d821321158fa2a9d0c1ebcdfb3-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-594b963ee8b55311db61f9612f3011096900256f8e763ccd3727749dce69a1b1-V.jpg"><img alt="" title="" src="images/image-0-02-05-594b963ee8b55311db61f9612f3011096900256f8e763ccd3727749dce69a1b1-V.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-705fe7dc102f0084280ad7bb9439ad517e1e2791597973c1aaae73738dcce171-V-1.jpg"><img alt="" title="" src="images/image-0-02-05-705fe7dc102f0084280ad7bb9439ad517e1e2791597973c1aaae73738dcce171-V-1.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/image-0-02-05-03035c29ae03125fc78832d66556d6a5265bf64f854af64ed1ad3c82931530bd-V.jpg"><img alt="" title="" src="images/image-0-02-05-03035c29ae03125fc78832d66556d6a5265bf64f854af64ed1ad3c82931530bd-V.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMG_20171006_171514.jpg"><img alt="" title="" src="images/IMG_20171006_171514.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMG_20171006_171627.jpg"><img alt="" title="" src="images/IMG_20171006_171627.jpg" style="width:248px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMG_20171103_120818.jpg"><img alt="" title="" src="images/IMG_20171103_120818.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/IMG_20171103_120825.jpg"><img alt="" title="" src="images/IMG_20171103_120825.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/%11.jpg"><img alt="" title="" src="images/%11.jpg" style="width:249px;height:186px;"></a>
      </td>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/%24%3E%42%3E-0013.jpg"><img alt="" title="" src="images/%24%3E%42%3E-0013.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
   <tr>
      <td class="figure" style="width:249px;height:186px">
      <a href="images/%24%3E%42%3E-0014.jpg"><img alt="" title="" src="images/%24%3E%42%3E-0014.jpg" style="width:249px;height:186px;"></a>
      </td>
   </tr>
</table>
</div>
</div>
</body>
</html>