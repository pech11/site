<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Главная</title>
<meta name="generator" content="WYSIWYG Web Builder 9 - http://www.wysiwygwebbuilder.com">
<style type="text/css">
html, body
{
   height: 100%;
}
div#space
{
   width: 1px;
   height: 50%;
   margin-bottom: -3051px;
   float:left
}
div#container
{
   width: 1002px;
   height: 6103px;
   margin: 0 auto;
   position: relative;
   clear: left;
}
body
{
   background-color: #FFFFFF;
   background-image: url(images/cvetnoy_korichnevyi_kirpich.png);
   color: #000000;
   font-family: Arial;
   font-size: 13px;
   margin: 0;
   padding: 0;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#Image1
{
   border: 0px #000000 solid;
}
#Image2
{
   border: 0px #000000 solid;
}
#Image3
{
   border: 0px #000000 solid;
}
#Marquee1
{
   background-color: transparent;
   background-image: url(images/index_Marquee1_bkgrnd.png);
   background-repeat: repeat-x;
   background-position: left top;
   border: 1px #C0C0C0 solid;
   text-align: center;
}
#SlideShow1 .image
{
   border-width: 0;
   left: 0;
   top: 0;
}
#wb_Text1 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text1 div
{
   text-align: left;
}
#wb_Text2 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text2 div
{
   text-align: left;
}
#wb_Text4 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: justify;
}
#wb_Text4 div
{
   text-align: justify;
}
#wb_Text3 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: justify;
}
#wb_Text3 div
{
   text-align: justify;
}
#wb_CssMenu2
{
   border: 0px #C0C0C0 solid;
   background-color: transparent;
}
#wb_CssMenu2 ul
{
   list-style-type: none;
   margin: 0;
   padding: 0;
   position: relative;
   display: inline-block;
}
#wb_CssMenu2 li
{
   float: left;
   margin: 0;
   padding: 0px 22px 0px 0px;
   width: 133px;
}
#wb_CssMenu2 a
{
   display: block;
   float: left;
   color: #2F4F4F;
   border: 1px #C0C0C0 solid;
   background-color: #EEEEEE;
   background-image: none;
   font-family: Arial;
   font-size: 24px;
   font-weight: normal;
   font-style: italic;
   text-decoration: none;
   width: 121px;
   height: 26px;
   padding: 0px 5px 0px 5px;
   vertical-align: middle;
   line-height: 26px;
   text-align: center;
}
#wb_CssMenu2 li:hover a, #wb_CssMenu2 a:hover
{
   color: #666666;
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
}
#wb_CssMenu2 li.firstmain
{
   padding-left: 0px;
}
#wb_CssMenu2 li.lastmain
{
   padding-right: 0px;
}
#wb_CssMenu2 li:hover, #wb_CssMenu2 li a:hover
{
   position: relative;
}
#wb_CssMenu2 a.withsubmenu
{
   padding: 0 5px 0 5px;
   width: 121px;
   background-image: none;
}
#wb_CssMenu2 li:hover a.withsubmenu, #wb_CssMenu2 a.withsubmenu:hover
{
   background-image: none;
}
#wb_CssMenu2 ul ul
{
   position: absolute;
   left: -9999px;
   top: -9999px;
   width: 100px;
   height: auto;
   border: none;
   background-color: transparent;
}
#wb_CssMenu2 ul :hover ul
{
   left: 0px;
   top: 28px;
   padding-top: 0px;
}
#wb_CssMenu2 .firstmain:hover ul
{
   left: 0px;
}
#wb_CssMenu2 li li
{
   width: 100px;
   padding: 0 0px 0px 0px;
   border: 0px #C0C0C0 solid;
   border-width: 0 0px;
}
#wb_CssMenu2 li li.firstitem
{
   border-top: 0px #C0C0C0 solid;
}
#wb_CssMenu2 li li.lastitem
{
   border-bottom: 0px #C0C0C0 solid;
}
#wb_CssMenu2 ul ul a, #wb_CssMenu2 ul :hover ul a
{
   float: none;
   margin: 0;
   width: 86px;
   height: auto;
   white-space: normal;
   padding: 1px 6px 1px 6px;
   background-color: #EEEEEE;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #000000;
   font-family: Arial;
   font-size: 21px;
   font-weight: normal;
   font-style: normal;
   line-height: 21px;
   text-align: left;
   text-decoration: none;
}
#wb_CssMenu2 ul :hover ul .firstitem a
{
   margin-top: 0px;
}
#wb_CssMenu2 ul ul :hover a, #wb_CssMenu2 ul ul a:hover, #wb_CssMenu2 ul ul :hover ul :hover a, #wb_CssMenu2 ul ul :hover ul a:hover
{
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #666666;
}
#wb_CssMenu2 br
{
   clear: both;
   font-size: 1px;
   height: 0;
   line-height: 0;
}
#PhotoGallery1
{
   border-spacing: 3px;
   width: 100%;
}
#PhotoGallery1 .figure
{
   padding: 0px 0px 0px 0px;
   text-align: center;
   vertical-align: top;
}
#PhotoGallery1 .figure img
{
   border: 0px #000000 solid;
}
#SlideShow2 .image
{
   border-width: 0;
   left: 0;
   top: 0;
}
</style>
<script type="text/javascript" src="jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-bars.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-blind.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-bounce.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-clip.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-drop.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-fade.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-fold.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-scale.min.js"></script>
<script type="text/javascript" src="jquery.ui.effect-slide.min.js"></script>
<script type="text/javascript" src="wb.slideshow.min.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
   $("#SlideShow1").slideshow(
   {
      interval: 7000,
      type: 'sequence',
      effect: 'bars',
      direction: 'vertical',
      effectlength: 2000
   });
   $("#SlideShow2").slideshow(
   {
      interval: 5000,
      type: 'sequence',
      effect: 'blind',
      direction: 'horizontal',
      effectlength: 2000
   });
});
</script>
<!-- Поместите код Google Analystics сюда -->
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape3" style="position:absolute;left:158px;top:246px;width:153px;height:50px;z-index:0;">
<img src="images/img0003.png" id="Shape3" alt="" style="border-width:0;width:153px;height:50px;"></div>
<div id="wb_Shape1" style="position:absolute;left:162px;top:217px;width:100px;height:100px;z-index:1;">
<img src="images/img0004.png" id="Shape1" alt="" style="border-width:0;width:100px;height:100px;"></div>
<div id="wb_Shape2" style="position:absolute;left:1px;top:31px;width:1039px;height:292px;z-index:2;">
<img src="images/img0002.png" id="Shape2" alt="" style="border-width:0;width:1039px;height:292px;"></div>
<div id="wb_Image1" style="position:absolute;left:387px;top:52px;width:209px;height:158px;z-index:3;">
<img src="images/ogon10.gif" id="Image1" alt="" style="width:209px;height:158px;"></div>
<div id="wb_Image2" style="position:absolute;left:23px;top:54px;width:153px;height:164px;z-index:4;">
<img src="images/img0055.png" id="Image2" alt="" style="width:153px;height:164px;"></div>
<div id="wb_Image3" style="position:absolute;left:798px;top:49px;width:188px;height:192px;z-index:5;">
<img src="images/barbecue.png" id="Image3" alt="" style="width:188px;height:192px;"></div>
<div id="wb_TextArt1" style="position:absolute;left:258px;top:46px;width:495px;height:49px;z-index:6;">
<img src="images/img0001.png" id="TextArt1" alt="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" title="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" style="border-width:0;width:495px;height:49px;"></div>
<div id="wb_Shape4" style="position:absolute;left:0px;top:422px;width:1047px;height:1291px;z-index:7;">
<img src="images/img0037.png" id="Shape4" alt="" style="border-width:0;width:1047px;height:1291px;"></div>
<marquee direction="left" scrolldelay="90" scrollamount="2" behavior="alternate" loop="0" style="position:absolute;left:86px;top:344px;width:851px;height:42px;z-index:8;" id="Marquee1"><span style="color:#000000;font-family:Arial;font-size:32px;"><em>Строительство уличных кухонных комплексов</em></span></marquee>
<div id="SlideShow1" style="position:absolute;left:481px;top:646px;width:518px;height:333px;z-index:9;">
<img class="image" style="width:518px;height:333px;" src="images/20170518_154329.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/20170906_160700.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/30078594%20%282%29.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/IMAG0644.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/image-0-02-04-5f3df8102e0373e5ec144d16e0a2d4c3cfbb1139b8a06de2eb368bd7e4892260-V-1.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/20170314_123947.jpg" alt="" title="">
<img class="image" style="width:518px;height:333px;display:none;" src="images/image-0-02-05-75c205ff7e1e89a76520350ea039f4714a6b6bd91b96a2cb716f883cba545554-V-1.jpg" alt="" title="">
</div>
<div id="wb_TextArt2" style="position:absolute;left:254px;top:427px;width:553px;height:65px;z-index:10;">
<img src="images/img0035.png" id="TextArt2" alt="&#1044;&#1086;&#1073;&#1088;&#1086; &#1087;&#1086;&#1078;&#1072;&#1083;&#1086;&#1074;&#1072;&#1090;&#1100;!" title="&#1044;&#1086;&#1073;&#1088;&#1086; &#1087;&#1086;&#1078;&#1072;&#1083;&#1086;&#1074;&#1072;&#1090;&#1100;!" style="border-width:0;width:553px;height:65px;"></div>
<div id="wb_Text1" style="position:absolute;left:270px;top:283px;width:489px;height:28px;z-index:11;text-align:left;">
<span style="color:#2F4F4F;font-family:Arial;font-size:24px;"><em>тел.096-582-45-78 эл.почта pavel@ua.fm</em></span></div>
<div id="wb_Text2" style="position:absolute;left:291px;top:1050px;width:250px;height:16px;z-index:12;text-align:left;">
&nbsp;</div>
<div id="wb_Text4" style="position:absolute;left:43px;top:496px;width:964px;height:632px;text-align:justify;z-index:13;">
<span style="color:#000000;font-family:Arial;font-size:24px;"><em>Рады приветствовать вас на нашем сайте.Наш коллектив занимается строительством уличных кухонных комплексов для приготовления пищи.Еда приготовленная в таких комплексах,является не только вкусной,но и полезной.По своей полезности такая пища не уступает еде приготовленной на пару,ну а вкусовые качества вне коментариев.Полезность и вкус приятно гармонируют с эстетикой.Данные сооружения <br>впишутся в абсолютно любой<br>дизайн,беседка,открытый участок,<br>закрытое помещение.Комплексы<br>выполняются из любого вида<br>кирпича облицовочного лицевого,<br>общестроительного кирпича <br>который используется под<br>облицовку любым строительным<br>материалом(камень натуральный и<br>исскуственный,облицовачная<br>плитка,штукатурка декоративная,<br>художественная лепка и т.д)<br>Ознакомиться с примерами наших работ вы можете в разделе <a href="./галерея.php">Галерея</a>.Связаться<br>с нами можно любым для вас удобным способом тел.</em></span><span style="color:#006400;font-family:Arial;font-size:24px;"><em>096-582-45-78</em></span><span style="color:#000000;font-family:Arial;font-size:24px;"><em> или эл.почта<br><a href="pavel@ua.fm">Pavel@ua.fm</a>.<br><br></em></span></div>
<div id="wb_Text3" style="position:absolute;left:119px;top:1089px;width:818px;height:398px;text-align:justify;z-index:14;">
<span style="color:#708090;font-family:Arial;font-size:27px;"><em><u>Н</u></em></span><span style="color:#008B8B;font-family:Arial;font-size:27px;"><em><u>а сегоднящний день мы оказываем такие услуги;<br></u></em></span><span style="color:#000000;font-family:Arial;font-size:13px;"><br></span><span style="color:#800000;font-family:Arial;font-size:24px;">строительство кирпичных мангалов-барбекю,<br>строительство кирпичных варочных плит под казан(азиатский,обычный),<br>строительство кирпичных тандыров,<br>строительство кирпичных коптилен,<br>строительство кирпичных духовок,<br>строительство столещниц,<br>строительство каминов,<br>монтаж каминных топок,<br>облицовка каминов,<br>облицовка мангалов,печей и т.д<br>строительство саун,<br>все виды работ с кафелем</span></div>
<div id="wb_CssMenu2" style="position:absolute;left:106px;top:241px;width:775px;height:100px;text-align:center;z-index:15;">
<ul>
<li class="firstmain"><a href="./index.php" target="_self">&#1043;&#1083;&#1072;&#1074;&#1085;&#1072;&#1103;</a>
</li>
<li><a class="withsubmenu" href="./галерея.php" target="_self">&#1043;&#1072;&#1083;&#1077;&#1088;&#1077;&#1103;</a>

<ul>
<li class="firstitem"><a href="#" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;</a>
</li>
<li><a href="./камины.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./кафель.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li class="lastitem"><a href="./сауны.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./о_нас.php" target="_self">&#1054;&nbsp;&#1085;&#1072;&#1089;</a>
</li>
<li><a class="withsubmenu" href="./статьи.php" target="_self">&#1057;&#1090;&#1072;&#1090;&#1100;&#1080;</a>

<ul>
<li class="firstitem"><a href="./камины.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./кафель.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li><a href="./мангалы_печи.php" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;&nbsp;&#1087;&#1077;&#1095;&#1080;</a>
</li>
<li class="lastitem"><a href="./сауны.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./контакты.php" target="_self">&#1050;&#1086;&#1085;&#1090;&#1072;&#1082;&#1090;&#1099;</a>
</li>
</ul>
<br>
</div>
<div id="wb_PhotoGallery1" style="position:absolute;left:609px;top:658px;width:215px;height:321px;z-index:16;">
<table id="PhotoGallery1">
</table>
</div>
<div id="SlideShow2" style="position:absolute;left:478px;top:645px;width:538px;height:350px;z-index:17;">
<img class="image" style="width:538px;height:350px;" src="images/20170906_160700.jpg" alt="" title="">
<img class="image" style="width:538px;height:350px;display:none;" src="images/20170518_154329.jpg" alt="" title="">
<img class="image" style="width:538px;height:350px;display:none;" src="images/IMG_20171006_171627.jpg" alt="" title="">
</div>
</div>
</body>
</html>