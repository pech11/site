<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>;)</title>
<meta name="generator" content="WYSIWYG Web Builder 9 - http://www.wysiwygwebbuilder.com">
<style type="text/css">
html, body
{
   height: 100%;
}
div#space
{
   width: 1px;
   height: 50%;
   margin-bottom: -3051px;
   float:left
}
div#container
{
   width: 1002px;
   height: 6103px;
   margin: 0 auto;
   position: relative;
   clear: left;
}
body
{
   background-color: #FFFFFF;
   background-image: url(images/cvetnoy_korichnevyi_kirpich.png);
   color: #000000;
   font-family: Arial;
   font-size: 13px;
   margin: 0;
   padding: 0;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#Image1
{
   border: 0px #000000 solid;
}
#Image2
{
   border: 0px #000000 solid;
}
#Image3
{
   border: 0px #000000 solid;
}
#Marquee1
{
   background-color: transparent;
   background-image: url(images/%41%42%30%42%4C%38_Marquee1_bkgrnd.png);
   background-repeat: repeat-x;
   background-position: left top;
   border: 1px #C0C0C0 solid;
   text-align: center;
}
#wb_CssMenu2
{
   border: 0px #C0C0C0 solid;
   background-color: transparent;
}
#wb_CssMenu2 ul
{
   list-style-type: none;
   margin: 0;
   padding: 0;
   position: relative;
   display: inline-block;
}
#wb_CssMenu2 li
{
   float: left;
   margin: 0;
   padding: 0px 21px 0px 0px;
   width: 115px;
}
#wb_CssMenu2 a
{
   display: block;
   float: left;
   color: #2F4F4F;
   border: 1px #C0C0C0 solid;
   background-color: #EEEEEE;
   background-image: none;
   font-family: Arial;
   font-size: 24px;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   width: 103px;
   height: 26px;
   padding: 0px 5px 0px 5px;
   vertical-align: middle;
   line-height: 26px;
   text-align: center;
}
#wb_CssMenu2 li:hover a, #wb_CssMenu2 a:hover
{
   color: #666666;
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
}
#wb_CssMenu2 li.firstmain
{
   padding-left: 0px;
}
#wb_CssMenu2 li.lastmain
{
   padding-right: 0px;
}
#wb_CssMenu2 li:hover, #wb_CssMenu2 li a:hover
{
   position: relative;
}
#wb_CssMenu2 a.withsubmenu
{
   padding: 0 5px 0 5px;
   width: 103px;
   background-image: none;
}
#wb_CssMenu2 li:hover a.withsubmenu, #wb_CssMenu2 a.withsubmenu:hover
{
   background-image: none;
}
#wb_CssMenu2 ul ul
{
   position: absolute;
   left: -9999px;
   top: -9999px;
   width: 100px;
   height: auto;
   border: none;
   background-color: transparent;
}
#wb_CssMenu2 ul :hover ul
{
   left: 0px;
   top: 28px;
   padding-top: 0px;
}
#wb_CssMenu2 .firstmain:hover ul
{
   left: 0px;
}
#wb_CssMenu2 li li
{
   width: 100px;
   padding: 0 0px 0px 0px;
   border: 0px #C0C0C0 solid;
   border-width: 0 0px;
}
#wb_CssMenu2 li li.firstitem
{
   border-top: 0px #C0C0C0 solid;
}
#wb_CssMenu2 li li.lastitem
{
   border-bottom: 0px #C0C0C0 solid;
}
#wb_CssMenu2 ul ul a, #wb_CssMenu2 ul :hover ul a
{
   float: none;
   margin: 0;
   width: 86px;
   height: auto;
   white-space: normal;
   padding: 5px 6px 5px 6px;
   background-color: #EEEEEE;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #696969;
   font-family: Arial;
   font-size: 13px;
   font-weight: normal;
   font-style: normal;
   line-height: 13px;
   text-align: left;
   text-decoration: none;
}
#wb_CssMenu2 ul :hover ul .firstitem a
{
   margin-top: 0px;
}
#wb_CssMenu2 ul ul :hover a, #wb_CssMenu2 ul ul a:hover, #wb_CssMenu2 ul ul :hover ul :hover a, #wb_CssMenu2 ul ul :hover ul a:hover
{
   background-color: #C0C0C0;
   background-image: none;
   border: 1px #C0C0C0 solid;
   color: #666666;
}
#wb_CssMenu2 br
{
   clear: both;
   font-size: 1px;
   height: 0;
   line-height: 0;
}
</style>
<!-- ��������� ��� Google Analystics ���� -->
</head>
<body>
<div id="space"><br></div>
<div id="container">
<div id="wb_Shape3" style="position:absolute;left:158px;top:246px;width:153px;height:50px;z-index:0;">
<img src="images/img0025.png" id="Shape3" alt="" style="border-width:0;width:153px;height:50px;"></div>
<div id="wb_Shape1" style="position:absolute;left:162px;top:217px;width:100px;height:100px;z-index:1;">
<img src="images/img0026.png" id="Shape1" alt="" style="border-width:0;width:100px;height:100px;"></div>
<div id="wb_Shape2" style="position:absolute;left:1px;top:31px;width:1039px;height:292px;z-index:2;">
<img src="images/img0027.png" id="Shape2" alt="" style="border-width:0;width:1039px;height:292px;"></div>
<div id="wb_Image1" style="position:absolute;left:397px;top:85px;width:209px;height:158px;z-index:3;">
<img src="images/ogon10.gif" id="Image1" alt="" style="width:209px;height:158px;"></div>
<div id="wb_Image2" style="position:absolute;left:14px;top:73px;width:153px;height:164px;z-index:4;">
<img src="images/15e7cdaa9fb7d490c175c7dcf436b32f.png" id="Image2" alt="" style="width:153px;height:164px;"></div>
<div id="wb_Image3" style="position:absolute;left:806px;top:66px;width:188px;height:177px;z-index:5;">
<img src="images/barbecue.png" id="Image3" alt="" style="width:188px;height:177px;"></div>
<div id="wb_TextArt1" style="position:absolute;left:256px;top:62px;width:495px;height:49px;z-index:6;">
<img src="images/img0028.png" id="TextArt1" alt="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" title="&#1041;&#1040;&#1056;&#1041;&#1045;&#1050;&#1070; &#1055;&#1045;&#1063;&#1048; &#1050;&#1040;&#1052;&#1048;&#1053;&#1067;" style="border-width:0;width:495px;height:49px;"></div>
<div id="wb_Shape4" style="position:absolute;left:0px;top:414px;width:1039px;height:942px;z-index:7;">
<a href="./������.php"><img src="images/img0029.png" id="Shape4" alt="" style="border-width:0;width:1039px;height:942px;"></a></div>
<marquee direction="left" scrolldelay="90" scrollamount="2" behavior="alternate" loop="0" style="position:absolute;left:86px;top:344px;width:851px;height:42px;z-index:8;" id="Marquee1"><span style="color:#000000;font-family:Arial;font-size:32px;"><em>������������� ������� �������� ����������</em></span></marquee>
<div id="wb_CssMenu2" style="position:absolute;left:150px;top:266px;width:680px;height:100px;text-align:center;z-index:9;">
<ul>
<li class="firstmain"><a href="./index.php" target="_self">&#1043;&#1083;&#1072;&#1074;&#1085;&#1072;&#1103;</a>
</li>
<li><a class="withsubmenu" href="./�������.php" target="_self">&#1043;&#1072;&#1083;&#1077;&#1088;&#1077;&#1103;</a>

<ul>
<li class="firstitem"><a href="./�������.php" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;</a>
</li>
<li><a href="./������.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./������.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li class="lastitem"><a href="./�����.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./�_���.php" target="_self">&#1054;&nbsp;&#1085;&#1072;&#1089;</a>
</li>
<li><a class="withsubmenu" href="./������.php" target="_self">&#1057;&#1090;&#1072;&#1090;&#1100;&#1080;</a>

<ul>
<li class="firstitem"><a href="./������.php" target="_self">&#1082;&#1072;&#1084;&#1080;&#1085;&#1099;</a>
</li>
<li><a href="./������.php" target="_self">&#1082;&#1072;&#1092;&#1077;&#1083;&#1100;</a>
</li>
<li><a href="./�������_����.php" target="_self">&#1084;&#1072;&#1085;&#1075;&#1072;&#1083;&#1099;&nbsp;&#1087;&#1077;&#1095;&#1080;</a>
</li>
<li class="lastitem"><a href="./�����.php" target="_self">&#1089;&#1072;&#1091;&#1085;&#1099;</a>
</li>
</ul>
</li>
<li><a href="./��������.php" target="_self">&#1050;&#1086;&#1085;&#1090;&#1072;&#1082;&#1090;&#1099;</a>
</li>
</ul>
<br>
</div>
<div id="wb_Shape8" style="position:absolute;left:520px;top:440px;width:191px;height:37px;z-index:10;">
<a href="./������_������������.php"><img src="images/img0036.png" id="Shape8" alt="" style="border-width:0;width:191px;height:37px;"></a></div>
<div id="wb_Shape5" style="position:absolute;left:524px;top:493px;width:191px;height:37px;z-index:11;">
<a href="./������_������������.php"><img src="images/img0043.png" id="Shape5" alt="" style="border-width:0;width:191px;height:37px;"></a></div>
</div>
</body>
</html>